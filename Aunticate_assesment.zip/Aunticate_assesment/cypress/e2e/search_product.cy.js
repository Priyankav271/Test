describe('Amazon Frontend Automation', () => {

  beforeEach(() => {
    cy.visit('https://www.amazon.in/')
  })

  it('Searches for a product and captures details', () => {
    const productName = "Titan watch"
    cy.get('#twotabsearchtextbox')
      .type(productName)
      .type('{enter}');
    cy.get('[data-component-type="s-search-result"]')
      .first()
      .within(() => {

        // Capture product details
        const name = cy.get('h2').invoke('text').then(text => text.trim());
        const price = cy.get('.a-price .a-offscreen').invoke('text').then(text => text.trim());
        const link = cy.get('h2 a').invoke('attr', 'href').then(href => href.trim());

        // Log product details to the Cypress command log
        cy.then(() => {
          cy.log('Product Name: ', name)
          cy.log('Product Price: ', price)
          cy.log('Product Link: ', link)
        })

        // Click on the product link to navigate to the product details page
        cy.get('h2 a').click()
      })
  })

  it('Navigates to Add to Cart Screen', () => {
    // Click on "Add to Cart" button
    cy.get('#add-to-cart-button').click()
    cy.get('#attach-added-to-cart-alert').should('be.visible'); // Example wait for cart modal
  })

  it('Navigates to Buy Now Screen', () => {
    // Click on "Proceed to Buy" or "Buy Now" button
    cy.get('#hlb-ptc-btn-native').click()
  })

  it('Navigates to Payment Gateway Screen', () => {
    // Proceed to Payment Gateway (no actual payment will be performed)
    cy.get('#continue-top').click()
    cy.url().should('include', 'pay.amazon.in');
  })

})
