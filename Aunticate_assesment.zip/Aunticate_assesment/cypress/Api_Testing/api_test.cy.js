describe('Amazon.in API Tests', () => {
    it('should return search results for a product', () => {
      cy.request({
        method: 'GET',
        url: 'https://api.amazon.in/search-products', // replace with actual endpoint
        qs: {
          query: 'laptop',
          category: 'electronics'
        }
      }).then((response) => {
        expect(response.status).to.eq(200);
        // Validate response structure and content
        expect(response.body).to.have.property('products');
        // Add more assertions as needed
      });
    });
  });

  it('should validate product details consistency', () => {
    // Suppose frontend automation has product details
    const frontendProductDetails = {
      name: 'Laptop',
      price: 500,
      // Add more details as per frontend
    };
  
    // Retrieve product details from API (example)
    cy.request({
      method: 'GET',
      url: 'https://api.amazon.in/product-details', // replace with actual endpoint
      qs: {
        productId: '123456'
      }
    }).then((response) => {
      // Compare with frontendProductDetails
      expect(response.body.name).to.eq(frontendProductDetails.name);
      expect(response.body.price).to.eq(frontendProductDetails.price);
      // Add more validations as needed
    });
  });

  it('should use values from search API in another request', () => {
    // Search for a product
    cy.request({
      method: 'GET',
      url: 'https://api.flipkart.in/search-products', // replace with actual endpoint
      qs: {
        query: 'mobile',
        category: 'electronics'
      }
    }).then((searchResponse) => {
      expect(searchResponse.status).to.eq(200);
      // Extract product ID from search response
      const productId = searchResponse.body.products[0].id;
  
      // Use product ID to fetch detailed information
      cy.request({
        method: 'GET',
        url: 'https://api.flipkart.in/product-details',
        qs: {
          productId: productId
        }
      }).then((detailsResponse) => {
        expect(detailsResponse.status).to.eq(200);
        // Validate detailsResponse as needed
      });
    });
  });
  