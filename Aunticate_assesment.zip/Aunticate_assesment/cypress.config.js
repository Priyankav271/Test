const { defineConfig } = require('cypress')

module.exports = defineConfig({
    projectId: 'pu8c3p',
    reporter: 'cypress-multi-reporters',
    defaultCommandTimeout: 30000,
    requestTimeout: 15000,
    responseTimeout: 30000,
    pageLoadTimeout: 30000,
    reporterOptions: {
        reporterEnabled: 'cypress-mochawesome-reporter, mocha-junit-reporter',
        cypressMochawesomeReporterReporterOptions: {
            reportDir: 'cypress/reports',
            charts: true,
            reportPageTitle: 'AutomationRunResult',
            embeddedScreenshots: true,
            inlineAssets: true,
            overwrite: false,
            html: 'true',
            json: true,
            video: false,
            videoCompression: 32,
            videoUploadOnPasses: true,
        },
        mochaJunitReporterReporterOptions: {
            mochaFile: 'cypress/reports/junit/results-[hash].xml',
            attachments: true,
        },

    },
    video: false,
    chromeWebSecurity: false,
    e2e: {
        // We've imported your old cypress plugins here.
        // You may want to clean this up later by importing these.
        setupNodeEvents(on, config) {
            return require('./cypress/plugins/index.js')(on, config)
        },
        experimentalSessionAndOrigin: true,
    },

}),

// cypress.json
{
    "baseUrl": "http://localhost:8080/",
    "numTestsKeptInMemory": 0,
}

